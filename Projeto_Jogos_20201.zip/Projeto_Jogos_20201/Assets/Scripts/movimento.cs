﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movimento : MonoBehaviour
{

    float velocidade;
    GameObject[] paredes;
    float novo_x, novo_y, novo_z;
    Vector3 old_transform;
    // Start is called before the first frame update
    void Start()
    {
        paredes = GameObject.FindGameObjectsWithTag("Parede");
        velocidade = 2;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey("w"))
        {
            novo_x = 0;
            novo_y = 0;
            novo_z = (velocidade * Time.deltaTime);
            transform.Translate(novo_x, novo_y, novo_z);
        }

        if (Input.GetKey("s"))
        {
            novo_x = 0;
            novo_y = 0;
            novo_z = (-velocidade * Time.deltaTime);
            transform.Translate(novo_x, novo_y, novo_z);
        }

        if (Input.GetKey("a"))
        {
            novo_x = (-velocidade * Time.deltaTime);
            novo_y = 0;
            novo_z = 0;
            transform.Translate(novo_x, novo_y, novo_z);
        }

        if (Input.GetKey("d"))
        {
            novo_x = (velocidade * Time.deltaTime);
            novo_y = 0;
            novo_z = 0;
            transform.Translate(novo_x, novo_y, novo_z);
        }



    }
}
